package com.wowcher;
public class WowcherClass {

	public static void main(String[] args) {
		String[] hour= {"one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen","twenty","twenty one", "twenty two", "twenty three", "twenty four"};
		String[] minutes={"one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen","twenty","twenty one", "twenty two", "twenty three", "twenty four", "twenty five", "twenty six", "twenty seven", "twenty eight", "twenty nine", "thirty", "thirty one","thirty two", "thirty three", "thirty four", "thirty five", "thirty six", "thirty seven", "thirty eight", "thirty nine", "forty", "forty one" , "forty two", "forty three", "forty four", "forty five", "forty six", "forty seven", "forty eight", "forty nine", "fifty", "fifty one",  "fifty two",  "fifty three",  "fifty four",  "fifty five",  "fifty six",  "fifty seven",  "fifty eight",  "fifty nine", "sixty"};
		
		int h=java.time.LocalTime.now().getHour();
		int m=java.time.LocalTime.now().getMinute();
		
			if(h==0 && m==0)
				System.out.println("It's Midnight");
			else if(h==12 && m==0)	
				System.out.println("It's Midday");
			else			
				System.out.println("It's "+hour[h-1]+" "+minutes[m-1]);
	}
}
